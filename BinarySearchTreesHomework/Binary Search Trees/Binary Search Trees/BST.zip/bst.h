#include <cstddef>
#include <iostream>
#ifndef BST_H
#define BST_H

using namespace std;

template<class Item>
class bstNode
{
public:
	//constructor
	bstNode(const Item& init_data, bstNode* init_left=NULL, bstNode* init_right= NULL)
    {
        data_field = init_data;
        left_field = init_left;
        right_field = init_right;
    }
	//helper functions if you need them ..
	//I think I haven't used any of them so far
	//Item& get_data() {return data_field;}
	void set_data(Item& target) {data_field=target;}
	bstNode*& get_left() {return left_field;}
	bstNode*& get_right() {return right_field;}
	
	//FUNCTIONS YOU IMPLEMENT BELOW
	bool find(Item& targetData);
	void insert(Item& targetData);
	void remove(Item& targetData);
	int size();
	void traverse();
    Item& get_data() {
		return data_field;
	}
	
	//our private variables (we just have 3)
private:
    Item data_field; //our data
    bstNode* left_field; //pointer to left child
    bstNode* right_field; //pointer to right child
    bstNode* get_min(bstNode<Item>*& successor_parent);
    void replace_node_in_parent(bstNode<Item>* parent, bstNode<Item>* new_node);
    void binary_tree_delete(bstNode<Item>* parent, Item& targetValue);
    
};
//ALL OUR IMPLEMENTATIONS GO IN HERE-- NO .CPP FILE FOR BSTNODE BECUASE IT'S A TEMPLATE CLASS
template<class Item>
bool bstNode<Item>::find(Item& targetData)
{
    if (data_field == targetData)
    {
        return true;
    }
    if(left_field == NULL && right_field == NULL)
    {
        return false;
    }
    if(left_field != NULL)
    {
        if(left_field -> find(targetData) == true)
        {
            return true;
        }
    }
    if(right_field != NULL)
    {
        if(right_field -> find(targetData) == true)
        {
            return true;
        }
    }
    return false;
    //check my self, check my children... if I find targetData I return true, else false

}
template<class Item>
void bstNode<Item>::insert(Item& targetData)
{
    if(targetData < data_field)
    {
        if(left_field == NULL){
            left_field = new bstNode<Item>(targetData);
        }
        else
        {
            left_field->insert(targetData);
        }
    }
    else if(targetData > data_field)
    {
        if(right_field == NULL)
        {
            right_field = new bstNode<Item>(targetData);
        }
        else
        {
            right_field->insert(targetData);
        }
    }
    else
    {
        return;
    }
}
//go through and find the correct place to insert a new node
//with this data, remember that you print out the tree in
//that specific format after you insert!

template<class Item>
void bstNode<Item>::traverse()
{
if(left_field != NULL){
    left_field->traverse();
	}
    cout << data_field;
	if(right_field !=NULL){
		right_field->traverse();
	}
}
//{
//    //print out the sequence of data using IN ORDER traversal
//	// IN ORDER: left, self, right
//	
//	cout << get_left() << endl;
//	cout << get_data() << endl;
//	cout << get_right() << endl;
//	
//	if (get_left() != '\0') {
//		left_field->traverse();
//	}
//    if (get_right() != '\0') {
//		right_field->traverse();
//	}
//	//print out the sequence of data using IN ORDER traversal
//}

template<class Item>
void bstNode<Item>::remove(Item& targetData)
{
//    if (targetData < data_field)
//    {
//        if (left != NULL)
//            return left->remove(Item, this);
//        else
//            return NULL;
//    } else if (Item > this->Item) {
//        if (right != NULL)
//            return right->remove(Item, this);
//        else
//            return NULL;
//    } else {
//        if (left != NULL && right != NULL) {
//            this->Item = right->minValue();
//            return right->remove(this->value, this);
//        } else if (targetData->left == this) {
//            targetData->left = (left != NULL) ? left : right;
//            return this;
//        } else if (targetData->right == this) {
//            targetData->right = (left != NULL) ? left : right;
//            return this;
//        }
//    }
	//go through and remove the item and remake the tree
    
    binary_tree_delete(NULL, targetData);
}

template<class Item>
int bstNode<Item>::size()
{
    int i=1;
    if(left_field == NULL && right_field == NULL)
    {
        return 1;
    }
    if(left_field != NULL)
    {
        i += left_field -> size();
    }
    if (right_field != NULL)
    {
        i += right_field -> size();
    }
    return i;
	//go through and count the number of nodes in this
}

template<class Item>
bstNode<Item>* bstNode<Item>::get_min(bstNode<Item>*& successor_parent)
{
    bstNode<Item>* cursor;
    
    cursor = this;
    while (cursor->left_field != NULL)
    {
        successor_parent = cursor;
        cursor = cursor->left_field;
    }
    
    return cursor;
}

template<class Item>
void bstNode<Item>::replace_node_in_parent(bstNode<Item>* parent, bstNode<Item>* new_node)
{
    if (parent != NULL)
    {
        if (this == parent->left_field)
        {
            delete parent->left_field;
            parent->left_field = new_node;
        }
        else // we must be the right child
        {
            delete parent->right_field;
            parent->right_field = new_node;
        }
    }
    else
    {
        // how to handle deletion of the root?
    }
    
}

template<class Item>
void bstNode<Item>::binary_tree_delete(bstNode<Item>* parent, Item& targetValue)
{
    bstNode<Item>* successor;
    bstNode<Item>* successor_parent;
    Item new_value;
    
    cerr << " *********** " << endl;
    cerr << "targetValue = " << targetValue << endl;
    cerr << "data_field = " << data_field << endl;
    
    if (targetValue < data_field)
    {
        left_field->binary_tree_delete(this, targetValue);
    }
    else if (targetValue > data_field)
    {
        right_field->binary_tree_delete(this, targetValue);
    }
    else
    {
        cerr << "Found the matching node..." << endl;
        if (left_field != NULL && right_field != NULL)
        {
            cerr << "we have both children" << endl;
            cerr << "we are " << data_field << endl;
            successor_parent = this;
            successor = right_field->get_min(successor_parent);
            new_value = successor->data_field;
            cerr << "would make recursive call " << endl;
            cerr << "successor_parent data = " << successor_parent->data_field << endl;
            cerr << "successor data = " << successor->data_field << endl;
            binary_tree_delete(successor_parent, successor->data_field);
            data_field = new_value;
        }
        else if (left_field != NULL)
        {
            cerr << "we have only a left child" << endl;
            replace_node_in_parent(parent, left_field);
        }
        else if (right_field != NULL)
        {
            cerr << "we have only a right child" << endl;
            replace_node_in_parent(parent, right_field);
        }
        else {
            cerr << "we are a leaf" << endl;
            replace_node_in_parent(parent, NULL);
        }
    }
}
#endif