README:

Name: Sheefali Tewari
There were errors/bugs earlier, but they have all been fixed. I don't think this program will work for large mazes. 